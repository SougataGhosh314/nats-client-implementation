package com.sougata.natscore.util;

public final class ProtobufUtils {

}
